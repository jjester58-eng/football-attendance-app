import type { Timestamp } from 'firebase/firestore';

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused' | 'injured';

export interface Student {
  id: string;
  name: string;
  parentEmail?: string;
  group?: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  classId: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  timestamp: number;
}

export interface Class {
  id: string;
  name: string;
  studentIds: string[];
}

// Firestore types
export interface FirestoreClass {
    name: string;
    studentIds: string[];
}

export interface FirestoreStudent {
    name: string;
    parentEmail?: string;
    group?: string;
}

export interface FirestoreAttendanceRecord {
    studentId: string;
    classId: string;
    date: string; // YYYY-MM-DD
    status: AttendanceStatus;
    timestamp: Timestamp;
}
