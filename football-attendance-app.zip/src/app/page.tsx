
"use client";

import AttendanceTracker from '@/components/attendance-tracker';
import Image from 'next/image';
import ProjectDownloader from '@/components/project-downloader';

export default function Home() {

  return (
    <main className="flex min-h-screen flex-col items-center justify-start p-4 sm:p-8 md:p-12">
      <div className="w-full max-w-7xl">
        <header className="mb-8 flex flex-col md:flex-row items-center justify-between text-center md:text-left gap-6">
          <div className="flex items-center gap-6">
             <Image
              src="https://3.files.edl.io/7221/23/08/08/202500-510f7e1a-ff25-44f4-ba9d-afb5b21bbf98.gif"
              alt="Football Logo"
              width={80}
              height={80}
              className="rounded-full"
              unoptimized
            />
            <div>
              <h1 className="text-4xl font-bold text-primary font-headline tracking-tight">Football Attendance</h1>
              <p className="text-muted-foreground mt-2 max-w-2xl mx-auto md:mx-0">
                AI-powered attendance tracking to ensure every player's presence is accounted for.
              </p>
            </div>
          </div>
          <div className="flex-shrink-0">
            <ProjectDownloader />
          </div>
        </header>

        <AttendanceTracker />
      </div>
    </main>
  );
}
