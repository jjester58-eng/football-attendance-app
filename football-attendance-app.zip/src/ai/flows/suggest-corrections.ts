'use server';

/**
 * @fileOverview AI-powered attendance correction suggestions.
 *
 * - suggestCorrections - A function that suggests corrections to attendance records.
 * - SuggestCorrectionsInput - The input type for the suggestCorrections function.
 * - SuggestCorrectionsOutput - The return type for the suggestCorrections function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestCorrectionsInputSchema = z.object({
  attendanceRecords: z
    .string()
    .describe(
      'A string representation of attendance records, including student names, dates, and attendance status (present, absent, late, excused).'
    ),
  attendancePolicies: z
    .string()
    .describe(
      'A string representation of the school or organization attendance policies.'
    ),
});
export type SuggestCorrectionsInput = z.infer<typeof SuggestCorrectionsInputSchema>;

const SuggestCorrectionsOutputSchema = z.object({
  suggestedCorrections: z
    .string()
    .describe(
      'A string containing suggested corrections to the attendance records, based on historical patterns and provided policies.'
    ),
  reasoning: z
    .string()
    .describe(
      'A string explaining the reasoning behind the suggested corrections.'
    ),
});
export type SuggestCorrectionsOutput = z.infer<typeof SuggestCorrectionsOutputSchema>;

export async function suggestCorrections(input: SuggestCorrectionsInput): Promise<SuggestCorrectionsOutput> {
  return suggestCorrectionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestCorrectionsPrompt',
  input: {schema: SuggestCorrectionsInputSchema},
  output: {schema: SuggestCorrectionsOutputSchema},
  prompt: `You are an AI assistant designed to analyze attendance records and suggest corrections based on historical patterns and established policies.

  Analyze the following attendance records:
  {{attendanceRecords}}

  Considering these attendance policies:
  {{attendancePolicies}}

  Suggest corrections to the attendance records, providing clear reasoning for each suggestion. Your suggestions should be formatted as a string that is easily parsable.
  Reason about edge cases and common reporting errors.
  It is imperative that the suggested corrections are in the same format as the input.
  `,
});

const suggestCorrectionsFlow = ai.defineFlow(
  {
    name: 'suggestCorrectionsFlow',
    inputSchema: SuggestCorrectionsInputSchema,
    outputSchema: SuggestCorrectionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
