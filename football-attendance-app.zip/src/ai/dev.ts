import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-corrections.ts';
