import { db } from './firebase';
import { 
    collection, 
    getDocs, 
    getDoc,
    doc, 
    writeBatch,
    Timestamp,
    query,
    where,
    onSnapshot,
    type Unsubscribe
} from 'firebase/firestore';
import type { Student, Class, AttendanceRecord, AttendanceStatus, FirestoreStudent, FirestoreClass, FirestoreAttendanceRecord } from '@/types';

// Fetch all classes
export const fetchClasses = (callback: (classes: Class[]) => void): Unsubscribe => {
    const q = query(collection(db, "classes"));
    return onSnapshot(q, (querySnapshot) => {
        const classes: Class[] = [];
        querySnapshot.forEach((doc) => {
            const data = doc.data() as FirestoreClass;
            classes.push({ ...data, id: doc.id });
        });
        callback(classes);
    });
};

// Fetch all students
export const fetchStudents = (callback: (students: Student[]) => void): Unsubscribe => {
    const q = query(collection(db, "students"));
    return onSnapshot(q, (querySnapshot) => {
        const students: Student[] = [];
        querySnapshot.forEach((doc) => {
            const data = doc.data() as FirestoreStudent;
            students.push({ ...data, id: doc.id });
        });
        callback(students);
    });
};

// Fetch all attendance records
export const fetchAttendanceRecords = (callback: (records: AttendanceRecord[]) => void): Unsubscribe => {
    const q = query(collection(db, "attendance"));
    return onSnapshot(q, (querySnapshot) => {
        const records: AttendanceRecord[] = [];
        querySnapshot.forEach((doc) => {
            const data = doc.data() as FirestoreAttendanceRecord;
            records.push({ 
                ...data, 
                id: doc.id,
                timestamp: data.timestamp instanceof Timestamp ? data.timestamp.toMillis() : Date.now()
            });
        });
        callback(records);
    });
};


export const addOrUpdateAttendance = async (studentId: string, classId: string, date: string, status: AttendanceStatus) => {
    const attendanceCol = collection(db, 'attendance');
    const q = query(attendanceCol, 
        where("studentId", "==", studentId), 
        where("classId", "==", classId),
        where("date", "==", date)
    );

    const batch = writeBatch(db);
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
        // Add new record
        const newRecordRef = doc(collection(db, 'attendance'));
        batch.set(newRecordRef, { studentId, classId, date, status, timestamp: Timestamp.now() });
    } else {
        // Update existing record
        const recordDoc = querySnapshot.docs[0];
        batch.update(recordDoc.ref, { status, timestamp: Timestamp.now() });
    }
    await batch.commit();
}


export const saveClasses = async (classesToSave: Class[]) => {
    const batch = writeBatch(db);
    
    classesToSave.forEach(c => {
        const docRef = doc(db, 'classes', c.id);
        batch.set(docRef, { name: c.name, studentIds: c.studentIds });
    });

    await batch.commit();
};

export const saveStudent = async (student: Student) => {
    const docRef = doc(db, 'students', student.id);
    const dataToSave: Omit<FirestoreStudent, 'id'> = { name: student.name };
    if (student.group) dataToSave.group = student.group;
    if (student.parentEmail) dataToSave.parentEmail = student.parentEmail;
    await writeBatch(db).set(docRef, dataToSave, { merge: true }).commit();
}

export const addStudentToClass = async (studentData: Omit<Student, 'id'>, classId: string) => {
    const batch = writeBatch(db);

    // Create the new student
    const newStudentRef = doc(collection(db, 'students'));
    batch.set(newStudentRef, studentData);

    // Add the new student's ID to the class
    const classRef = doc(db, 'classes', classId);
    const classDoc = await getDoc(classRef);
    if (classDoc.exists()) {
        const classData = classDoc.data() as FirestoreClass;
        const updatedStudentIds = [...classData.studentIds, newStudentRef.id];
        batch.update(classRef, { studentIds: updatedStudentIds });
    }

    await batch.commit();
}

export const deleteStudentsFromClass = async (studentIds: string[], classId: string) => {
    const batch = writeBatch(db);

    // 1. Remove students from the class's studentIds array
    const classRef = doc(db, 'classes', classId);
    const classDoc = await getDoc(classRef);
    if(classDoc.exists()) {
        const classData = classDoc.data() as FirestoreClass;
        const newStudentIds = classData.studentIds.filter(id => !studentIds.includes(id));
        batch.update(classRef, { studentIds: newStudentIds });
    }

    // 2. For each student, delete their main document and their attendance records.
    for (const studentId of studentIds) {
        // Delete student doc
        const studentRef = doc(db, 'students', studentId);
        batch.delete(studentRef);

        // Find and delete attendance records
        const attendanceQuery = query(collection(db, 'attendance'), where('studentId', '==', studentId));
        const attendanceSnapshot = await getDocs(attendanceQuery);
        attendanceSnapshot.forEach(doc => batch.delete(doc.ref));
    }

    await batch.commit();
}

export const importStudentsToClass = async (studentsToImport: Partial<Student>[], classId: string) => {
    const batch = writeBatch(db);
    const classRef = doc(db, 'classes', classId);
    
    const newStudentIds: string[] = [];

    for (const studentData of studentsToImport) {
        if (studentData.id) { // Update existing student
             const studentRef = doc(db, 'students', studentData.id);
             batch.update(studentRef, {
                 ...(studentData.name && { name: studentData.name }),
                 ...(studentData.group && { group: studentData.group }),
                 ...(studentData.parentEmail && { parentEmail: studentData.parentEmail }),
             });
        } else { // Create new student
            const newStudentRef = doc(collection(db, 'students'));
            batch.set(newStudentRef, {
                name: studentData.name || 'Unnamed Student',
                ...(studentData.group && { group: studentData.group }),
                ...(studentData.parentEmail && { parentEmail: studentData.parentEmail }),
            });
            newStudentIds.push(newStudentRef.id);
        }
    }
    
    // Add new students to the class list if any were created
    if (newStudentIds.length > 0) {
        const classDoc = await getDoc(classRef);
        if (classDoc.exists()) {
            const classData = classDoc.data() as FirestoreClass;
            const updatedStudentIds = [...classData.studentIds, ...newStudentIds];
            batch.update(classRef, { studentIds: updatedStudentIds });
        }
    }
    
    await batch.commit();
};
