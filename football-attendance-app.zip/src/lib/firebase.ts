// Import the functions you need from the SDKs you need
import { initializeApp, getApp, getApps } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
// This is a public configuration and is safe to expose.
const firebaseConfig = {
  apiKey: "FAKE_API_KEY",
  authDomain: "FAKE_AUTH_DOMAIN",
  projectId: "FAKE_PROJECT_ID",
  storageBucket: "FAKE_STORAGE_BUCKET",
  messagingSenderId: "FAKE_MESSAGING_SENDER_ID",
  appId: "FAKE_APP_ID"
};

// Initialize Firebase
const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
const db = getFirestore(app);

export { app, db };
