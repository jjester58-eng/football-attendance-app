"use client";

import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trash2, PlusCircle } from 'lucide-react';
import type { Class } from '@/types';
import { useToast } from '@/hooks/use-toast';

interface EditClassesDialogProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  classes: Class[];
  onSave: (classes: Class[]) => void;
}

export default function EditClassesDialog({
  isOpen,
  setIsOpen,
  classes,
  onSave,
}: EditClassesDialogProps) {
  const [editableClasses, setEditableClasses] = useState<Class[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      setEditableClasses(JSON.parse(JSON.stringify(classes)));
    }
  }, [isOpen, classes]);

  const handleNameChange = (id: string, newName: string) => {
    setEditableClasses(prev =>
      prev.map(c => (c.id === id ? { ...c, name: newName } : c))
    );
  };

  const handleAddClass = () => {
    const newClass: Class = {
      id: `class-${Date.now()}`,
      name: 'New Class',
      studentIds: [],
    };
    setEditableClasses(prev => [...prev, newClass]);
  };

  const handleDeleteClass = (id: string) => {
    if (editableClasses.length <= 1) {
        toast({
            variant: 'destructive',
            title: 'Cannot Delete',
            description: 'You must have at least one class.',
        });
        return;
    }
    setEditableClasses(prev => prev.filter(c => c.id !== id));
  };

  const handleSaveChanges = () => {
    const hasEmptyNames = editableClasses.some(c => c.name.trim() === '');
    if (hasEmptyNames) {
      toast({
        variant: 'destructive',
        title: 'Invalid Name',
        description: 'Class names cannot be empty.',
      });
      return;
    }
    onSave(editableClasses);
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Edit Classes</DialogTitle>
          <DialogDescription>
            Add, edit, or delete your class names here. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
          {editableClasses.map(c => (
            <div key={c.id} className="flex items-center gap-2">
              <div className="grid flex-1 gap-1.5">
                <Label htmlFor={`class-name-${c.id}`} className="sr-only">
                  Class Name
                </Label>
                <Input
                  id={`class-name-${c.id}`}
                  value={c.name}
                  onChange={e => handleNameChange(c.id, e.target.value)}
                  placeholder="Enter class name"
                />
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleDeleteClass(c.id)}
                className="text-red-500 hover:text-red-600"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
           <Button variant="outline" onClick={handleAddClass} className="mt-4">
            <PlusCircle className="mr-2 h-4 w-4" />
            Add New Class
          </Button>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSaveChanges}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
