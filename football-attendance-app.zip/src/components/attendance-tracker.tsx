
"use client";

import React, { useState, useMemo, useEffect, type FC } from 'react';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, CheckCircle2, XCircle, Clock, ShieldCheck, Download, Wand2, Mail, MoreHorizontal, Upload, Pencil, ShieldAlert, ArrowUpDown, Plus, Trash2 } from 'lucide-react';
import type { AttendanceRecord, AttendanceStatus, Student, Class } from '@/types';
import { cn, exportToCsv } from '@/lib/utils';
import { 
    fetchClasses, 
    fetchStudents, 
    fetchAttendanceRecords, 
    addOrUpdateAttendance, 
    saveClasses,
    addStudentToClass,
    saveStudent,
    deleteStudentsFromClass,
    importStudentsToClass,
} from '@/lib/firestore';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import SuggestCorrectionsDialog from '@/components/suggest-corrections-dialog';
import ImportStudentsDialog from '@/components/import-students-dialog';
import AttendanceReport from '@/components/attendance-report';
import EditClassesDialog from '@/components/edit-classes-dialog';
import EditStudentDialog from '@/components/edit-student-dialog';
import AddStudentDialog from '@/components/add-student-dialog';
import NotifyParentsDialog from '@/components/notify-parents-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';


const statusConfig: Record<
  AttendanceStatus,
  { label: string; icon: FC<{ className?: string }>; badge: string; iconColor: string; }
> = {
  present: { label: 'Present', icon: CheckCircle2, badge: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300', iconColor: 'text-green-500' },
  absent: { label: 'Absent', icon: XCircle, badge: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300', iconColor: 'text-red-500' },
  late: { label: 'Late', icon: Clock, badge: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300', iconColor: 'text-yellow-500' },
  excused: { label: 'Excused', icon: ShieldCheck, badge: 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300', iconColor: 'text-blue-500' },
  injured: { label: 'Injured', icon: ShieldAlert, badge: 'bg-orange-100 text-orange-800 dark:bg-orange-900/50 dark:text-orange-300', iconColor: 'text-orange-500' },
};

type SortableKeys = 'name' | 'group';

export default function AttendanceTracker() {
  const [students, setStudents] = useState<Student[]>([]);
  const [classes, setClasses] = useState<Class[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [sortConfig, setSortConfig] = useState<{ key: SortableKeys; direction: 'ascending' | 'descending' }>({ key: 'name', direction: 'ascending' });
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);
  
  const [isSuggestCorrectionsOpen, setSuggestCorrectionsOpen] = useState(false);
  const [isImportStudentsOpen, setImportStudentsOpen] = useState(false);
  const [isEditClassesOpen, setEditClassesOpen] = useState(false);
  const [isAddStudentOpen, setAddStudentOpen] = useState(false);
  const [isNotifyParentsOpen, setNotifyParentsOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  const { toast } = useToast();

  useEffect(() => {
    setIsLoading(true);
    const unsubClasses = fetchClasses((fetchedClasses) => {
        setClasses(fetchedClasses);
        if (fetchedClasses.length > 0 && !selectedClassId) {
            setSelectedClassId(fetchedClasses[0].id);
        }
        setIsLoading(false);
    });

    const unsubStudents = fetchStudents(setStudents);
    const unsubAttendance = fetchAttendanceRecords(setAttendanceRecords);

    return () => {
        unsubClasses();
        unsubStudents();
        unsubAttendance();
    };
  }, [selectedClassId]);


  const handleStatusChange = async (studentId: string, status: AttendanceStatus) => {
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    try {
        await addOrUpdateAttendance(studentId, selectedClassId, dateStr, status);
    } catch (error) {
        toast({
            variant: 'destructive',
            title: 'Error',
            description: 'Failed to update attendance.'
        })
    }
  };

  const studentAbsenceCount = useMemo(() => {
    const counts: Record<string, number> = {};
    attendanceRecords.forEach(record => {
      if(record.classId === selectedClassId && record.status === 'absent') {
        counts[record.studentId] = (counts[record.studentId] || 0) + 1;
      }
    });
    return counts;
  }, [attendanceRecords, selectedClassId]);

  const sortedRecords = useMemo(() => {
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    const selectedClass = classes.find(c => c.id === selectedClassId);
    if (!selectedClass) return [];
    
    const classStudents = students.filter(s => selectedClass.studentIds.includes(s.id));

    const records = classStudents.map((student) => {
      const record = attendanceRecords.find(
        (r) => r.studentId === student.id && r.date === dateStr && r.classId === selectedClassId
      );
      return {
        ...student,
        status: record?.status || 'present',
        timestamp: record?.timestamp,
        totalAbsences: studentAbsenceCount[student.id] || 0
      };
    });

    return [...records].sort((a, b) => {
      const aValue = a[sortConfig.key] || '';
      const bValue = b[sortConfig.key] || '';
      
      if (aValue < bValue) {
        return sortConfig.direction === 'ascending' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'ascending' ? 1 : -1;
      }
      return 0;
    });

  }, [selectedDate, attendanceRecords, students, classes, selectedClassId, studentAbsenceCount, sortConfig]);

  const handleSort = (key: SortableKeys) => {
    setSortConfig(prevConfig => {
      if (prevConfig.key === key && prevConfig.direction === 'ascending') {
        return { key, direction: 'descending' };
      }
      return { key, direction: 'ascending' };
    });
  };

  const handleExport = () => {
    const selectedClass = classes.find(c => c.id === selectedClassId);
    if (!selectedClass) return;

    const classStudents = students.filter(s => selectedClass.studentIds.includes(s.id));
    const classAttendance = attendanceRecords.filter(r => r.classId === selectedClassId);

    // Get all unique dates for this class, and sort them
    const allDates = [...new Set(classAttendance.map(r => r.date))].sort();

    const header = ['studentId', 'name', 'group', 'parentEmail', ...allDates];

    const dataToExport = classStudents.map(student => {
        const studentRow: (string | number)[] = [
            student.id,
            student.name,
            student.group || '',
            student.parentEmail || ''
        ];

        allDates.forEach(date => {
            const record = classAttendance.find(r => r.studentId === student.id && r.date === date);
            studentRow.push(record ? record.status : ''); // Add status or empty string
        });
        
        return studentRow;
    });

    dataToExport.unshift(header);
    exportToCsv(`attendance_${selectedClass.name.replace(/\s/g, '_')}.csv`, dataToExport);
    
    toast({
      title: "Export Successful",
      description: "Full attendance roster has been exported to CSV.",
    });
  };


  const handleNotifyClick = () => {
    const absentStudents = sortedRecords.filter(rec => rec.status === 'absent' && rec.parentEmail);
    if (absentStudents.length === 0) {
      toast({
        title: "No Absences to Report",
        description: "All students with registered parent emails are accounted for.",
      });
      return;
    }
    setNotifyParentsOpen(true);
  };
  
  const getAttendanceRecordsAsString = () => {
    return attendanceRecords
      .filter(r => r.classId === selectedClassId)
      .map(r => `Student ID: ${r.studentId}, Date: ${r.date}, Status: ${r.status}`).join('\n');
  };

  const handleImportStudents = async (importedData: Partial<Student>[]) => {
    try {
        await importStudentsToClass(importedData, selectedClassId);
        toast({
            title: 'Import Successful',
            description: `Roster has been updated.`,
        });
    } catch (error) {
        toast({
            variant: 'destructive',
            title: 'Import Failed',
            description: 'Could not import student data.',
        });
    }
  };

  const handleSaveClasses = async (updatedClasses: Class[]) => {
    try {
        await saveClasses(updatedClasses);
        if (!updatedClasses.some(c => c.id === selectedClassId)) {
            setSelectedClassId(updatedClasses[0]?.id || '');
        }
        toast({
            title: 'Classes Updated',
            description: 'Your class list has been saved.',
        });
    } catch (error) {
        toast({
            variant: 'destructive',
            title: 'Save Failed',
            description: 'Could not save classes.'
        });
    }
  };
  
  const handleSaveStudent = async (updatedStudent: Student) => {
    try {
        await saveStudent(updatedStudent);
        toast({
          title: 'Student Updated',
          description: `${updatedStudent.name}'s information has been saved.`,
        });
        setEditingStudent(null);
    } catch(error) {
        toast({
            variant: 'destructive',
            title: 'Update Failed',
            description: 'Could not update student.',
        });
    }
  };
  
  const handleAddStudent = async (student: Omit<Student, 'id'>) => {
    if (!selectedClassId) {
         toast({
            variant: 'destructive',
            title: 'No Class Selected',
            description: 'Please select a class before adding a student.',
        });
        return;
    }
    try {
        await addStudentToClass(student, selectedClassId);
        toast({
            title: 'Student Added',
            description: `${student.name} has been added to the class.`,
        });
    } catch (error) {
        toast({
            variant: 'destructive',
            title: 'Add Failed',
            description: 'Could not add student.',
        });
    }
  };

  const handleDeleteStudents = async () => {
    try {
        await deleteStudentsFromClass(selectedStudents, selectedClassId);
        toast({
            title: 'Students Deleted',
            description: `${selectedStudents.length} student(s) have been removed.`,
        });
        setSelectedStudents([]); // Clear selection
    } catch (error) {
         toast({
            variant: 'destructive',
            title: 'Delete Failed',
            description: 'Could not delete students.',
        });
    }
  };

  const handleSelectStudent = (studentId: string, isSelected: boolean) => {
    if (isSelected) {
      setSelectedStudents(prev => [...prev, studentId]);
    } else {
      setSelectedStudents(prev => prev.filter(id => id !== studentId));
    }
  };

  const handleSelectAll = (isAllSelected: boolean) => {
    if (isAllSelected) {
      setSelectedStudents(sortedRecords.map(r => r.id));
    } else {
      setSelectedStudents([]);
    }
  };

  const selectedClass = classes.find(c => c.id === selectedClassId);
  
  const renderSortIcon = (key: SortableKeys) => {
    if (sortConfig.key !== key) {
      return <ArrowUpDown className="h-4 w-4 ml-2 opacity-20" />;
    }
    return sortConfig.direction === 'ascending' ? 
      <ArrowUpDown className="h-4 w-4 ml-2 transform" /> : 
      <ArrowUpDown className="h-4 w-4 ml-2 transform rotate-180" />;
  };

  const isAllSelected = sortedRecords.length > 0 && selectedStudents.length === sortedRecords.length;
  const absentStudentsWithEmail = sortedRecords.filter(rec => rec.status === 'absent' && rec.parentEmail);

  if (isLoading) {
      return (
        <div className="w-full max-w-7xl p-4 sm:p-8 md:p-12">
            <Card>
                <CardHeader>
                    <Skeleton className="h-8 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <Skeleton className="h-10 w-full" />
                        <Skeleton className="h-10 w-full" />
                        <Skeleton className="h-10 w-full" />
                    </div>
                </CardContent>
            </Card>
        </div>
      )
  }

  return (
    <>
      <Tabs defaultValue="daily">
        <CardHeader>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <CardTitle>{selectedClass?.name || 'Select Class'} - {format(selectedDate, 'MMMM d, yyyy')}</CardTitle>
              <CardDescription>Log and manage student attendance for the selected day.</CardDescription>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Select value={selectedClassId} onValueChange={(value) => { setSelectedClassId(value); setSelectedStudents([]); }} disabled={!selectedClassId}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select a class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon" onClick={() => setEditClassesOpen(true)}><Pencil /></Button>
               <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-[240px] justify-start text-left font-normal",
                      !selectedDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
               <TabsList>
                <TabsTrigger value="daily">Daily</TabsTrigger>
                <TabsTrigger value="reports">Reports</TabsTrigger>
              </TabsList>
              <div className="flex items-center gap-2">
                 {selectedStudents.length > 0 && (
                   <AlertDialog>
                     <AlertDialogTrigger asChild>
                       <Button variant="destructive" size="icon"><Trash2 /></Button>
                     </AlertDialogTrigger>
                     <AlertDialogContent>
                       <AlertDialogHeader>
                         <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                         <AlertDialogDescription>
                           This action cannot be undone. This will permanently delete {selectedStudents.length} student(s) and all their attendance data.
                         </AlertDialogDescription>
                       </AlertDialogHeader>
                       <AlertDialogFooter>
                         <AlertDialogCancel>Cancel</AlertDialogCancel>
                         <AlertDialogAction onClick={handleDeleteStudents}>Continue</AlertDialogAction>
                       </AlertDialogFooter>
                     </AlertDialogContent>
                   </AlertDialog>
                 )}
                 <Button variant="outline" onClick={() => setAddStudentOpen(true)}><Plus/>Add Student</Button>
              </div>
            </div>
          </div>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-end gap-4 mt-4">
             <div className="flex items-center gap-2 flex-wrap">
                <Button variant="outline" onClick={() => setImportStudentsOpen(true)}><Upload/>Import</Button>
                <Button variant="outline" onClick={() => setSuggestCorrectionsOpen(true)}><Wand2/>Suggest</Button>
                <Button variant="outline" onClick={handleExport}><Download/>Export</Button>
                <Button onClick={handleNotifyClick}><Mail/>Notify</Button>
            </div>
          </div>
        </CardHeader>
        <TabsContent value="daily">
          <Card>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[40px]">
                         <Checkbox
                           checked={isAllSelected}
                           onCheckedChange={(checked) => handleSelectAll(!!checked)}
                           aria-label="Select all"
                         />
                      </TableHead>
                      <TableHead>
                        <Button variant="ghost" onClick={() => handleSort('name')}>
                          Student
                          {renderSortIcon('name')}
                        </Button>
                      </TableHead>
                      <TableHead className="hidden sm:table-cell">
                        <Button variant="ghost" onClick={() => handleSort('group')}>
                          Group
                          {renderSortIcon('group')}
                        </Button>
                      </TableHead>
                      <TableHead className="hidden sm:table-cell">Absences</TableHead>
                      <TableHead>
                        <div className="hidden md:flex items-center justify-start gap-4">
                          {Object.values(statusConfig).map(({ label, icon: Icon, iconColor }) => (
                            <div key={label} className="flex items-center gap-2">
                              <Icon className={cn("h-5 w-5", iconColor)} />
                              <span className="text-muted-foreground">{label}</span>
                            </div>
                          ))}
                        </div>
                        <span className="md:hidden">Status</span>
                      </TableHead>
                      <TableHead className="text-right"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedRecords.map((record) => (
                        <TableRow key={record.id} data-state={selectedStudents.includes(record.id) ? "selected" : ""}>
                          <TableCell>
                             <Checkbox
                               checked={selectedStudents.includes(record.id)}
                               onCheckedChange={(checked) => handleSelectStudent(record.id, !!checked)}
                               aria-label={`Select ${record.name}`}
                              />
                          </TableCell>
                          <TableCell className="font-medium">{record.name}</TableCell>
                          <TableCell className="hidden sm:table-cell text-muted-foreground">{record.group || 'N/A'}</TableCell>
                          <TableCell className="hidden sm:table-cell">
                             {record.totalAbsences > 0 ? <Badge variant={record.totalAbsences > 2 ? "destructive" : "secondary"}>{record.totalAbsences}</Badge> : null}
                          </TableCell>
                          <TableCell>
                            {/* Desktop icon buttons */}
                            <div className="hidden sm:flex items-center gap-1">
                                {Object.entries(statusConfig).map(([status, {icon: Icon, iconColor, label}]) => (
                                    <Button
                                        key={status}
                                        variant={record.status === status ? "outline" : "ghost"}
                                        size="icon"
                                        onClick={() => handleStatusChange(record.id, status as AttendanceStatus)}
                                        className={cn("border-2", record.status === status ? 'border-primary' : 'border-transparent')}
                                        aria-label={label}
                                    >
                                        <Icon className={cn("h-5 w-5", iconColor)} />
                                    </Button>
                                ))}
                            </div>
                            {/* Mobile dropdown */}
                            <div className="sm:hidden">
                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button variant="outline" className="flex items-center gap-2">
                                            {React.createElement(statusConfig[record.status].icon, { className: cn("h-5 w-5", statusConfig[record.status].iconColor) })}
                                            <span>{statusConfig[record.status].label}</span>
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent>
                                        {Object.entries(statusConfig).map(([status, {icon: Icon, label, iconColor}]) => (
                                            <DropdownMenuItem key={status} onSelect={() => handleStatusChange(record.id, status as AttendanceStatus)}>
                                                 <Icon className={cn("h-5 w-5 mr-2", iconColor)} />
                                                <span>{label}</span>
                                            </DropdownMenuItem>
                                        ))}
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                               <Button variant="ghost" size="icon" onClick={() => setEditingStudent(record)}>
                                <Pencil className="h-4 w-4" />
                                <span className="sr-only">Edit Student</span>
                              </Button>
                          </TableCell>
                        </TableRow>
                      )
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="reports">
           <AttendanceReport 
              attendanceRecords={attendanceRecords} 
              students={students} 
              classes={classes}
              selectedClassId={selectedClassId}
           />
        </TabsContent>
      </Tabs>
      <SuggestCorrectionsDialog
        isOpen={isSuggestCorrectionsOpen}
        setIsOpen={setSuggestCorrectionsOpen}
        attendanceRecordsString={getAttendanceRecordsAsString()}
        onApplySuggestions={(suggestions) => {
          // This is a simplified apply logic. A real app would parse this string.
          toast({ title: 'Suggestions Applied', description: 'Attendance records have been updated based on AI suggestions.' });
        }}
      />
      <ImportStudentsDialog
        isOpen={isImportStudentsOpen}
        setIsOpen={setImportStudentsOpen}
        onImport={handleImportStudents}
      />
      <EditClassesDialog
        isOpen={isEditClassesOpen}
        setIsOpen={setEditClassesOpen}
        classes={classes}
        onSave={handleSaveClasses}
      />
       {editingStudent && (
        <EditStudentDialog
            isOpen={!!editingStudent}
            setIsOpen={(isOpen) => !isOpen && setEditingStudent(null)}
            student={editingStudent}
            onSave={handleSaveStudent}
        />
      )}
      <AddStudentDialog
        isOpen={isAddStudentOpen}
        setIsOpen={setAddStudentOpen}
        onAdd={handleAddStudent}
      />
      <NotifyParentsDialog
        isOpen={isNotifyParentsOpen}
        setIsOpen={setNotifyParentsOpen}
        absentStudents={absentStudentsWithEmail}
      />
    </>
  );
}
