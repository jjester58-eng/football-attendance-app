"use client";

import React, { useState, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Upload, Download } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import type { Student } from '@/types';
import { exportToCsv } from '@/lib/utils';

interface ImportStudentsDialogProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  onImport: (students: Partial<Student>[]) => void;
}

// Robust CSV parser that correctly handles quoted fields, including commas within them.
function parseCsv(csvText: string): string[][] {
  const result: string[][] = [];
  const lines = csvText.trim().split(/\r\n|\n/); // Handles both windows and unix line endings
  const regex = /("([^"]|"")*"|[^,]*)(,|$)/g;

  for (const line of lines) {
    if (line.trim() === '') continue; // Skip empty lines

    const columns: string[] = [];
    // Reset regex state for each line
    let tempRegex = new RegExp(regex);
    let match;

    while ((match = tempRegex.exec(line)) && match[0]) {
        let value = match[1] || '';
        if (value.startsWith('"') && value.endsWith('"')) {
            // Remove surrounding quotes and unescape double quotes
            value = value.slice(1, -1).replace(/""/g, '"');
        }
        columns.push(value.trim());
    }
    result.push(columns);
  }
  return result;
}


export default function ImportStudentsDialog({
  isOpen,
  setIsOpen,
  onImport,
}: ImportStudentsDialogProps) {
  const [file, setFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type === 'text/csv' || selectedFile.name.endsWith('.csv')) {
        setFile(selectedFile);
        setError(null);
      } else {
        setError('Invalid file type. Please upload a CSV file.');
        setFile(null);
      }
    }
  };

  const handleDownloadTemplate = () => {
    const templateData = [
      ['studentId', 'name', 'group', 'parentEmail'],
      ['student-1', '"Doe, John"', 'Group A', 'john.parent@example.com'],
      ['', '"Smith, Jane"', 'Group B', ''],
    ];
    exportToCsv('student_template.csv', templateData);
    toast({
      title: 'Template Downloaded',
      description: 'A CSV template has been downloaded. Leave studentId blank for new students.',
    });
  };

  const handleImport = useCallback(() => {
    if (!file) {
      setError('Please select a file to import.');
      return;
    }
    setIsLoading(true);
    setError(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const rows = parseCsv(text);
        
        if (rows.length < 2) throw new Error('CSV is empty or contains only a header.');
        
        const headerRow = rows.shift();
        if(!headerRow) throw new Error('CSV header not found.');

        const header = headerRow.map(h => h.trim().toLowerCase().replace(/\s+/g, ''));
        
        const idIndex = header.indexOf('studentid');
        const nameIndex = header.indexOf('name');
        const groupIndex = header.indexOf('group');
        const emailIndex = header.indexOf('parentemail');

        if (nameIndex === -1) {
            throw new Error('CSV must contain a "name" column.');
        }

        const importedData = rows.map((cols, rowIndex) => {
            if (cols.every(col => col.trim() === '')) return null;

            const name = cols[nameIndex]?.trim();
            if (!name) {
                console.warn(`Skipping row ${rowIndex + 2}: missing name.`);
                return null;
            }
            
            const id = idIndex > -1 ? (cols[idIndex]?.trim() || undefined) : undefined;
            const parentEmail = emailIndex > -1 ? (cols[emailIndex]?.trim() || undefined) : undefined;
            const group = groupIndex > -1 ? (cols[groupIndex]?.trim() || undefined) : undefined;

            return { id, name, parentEmail, group };
        }).filter((s): s is Partial<Student> => s !== null);

        if (importedData.length === 0) {
          throw new Error('No valid student data found in the file.');
        }

        onImport(importedData);
        setIsOpen(false);
        setFile(null);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred during parsing.';
        setError(`Failed to parse CSV: ${errorMessage}`);
        toast({
            variant: 'destructive',
            title: 'Import Error',
            description: `Failed to parse CSV: ${errorMessage}`,
        });
      } finally {
        setIsLoading(false);
      }
    };
    reader.onerror = () => {
        setError('Failed to read the file.');
        setIsLoading(false);
    }
    reader.readAsText(file);
  }, [file, onImport, setIsOpen, toast]);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Import Students from CSV</DialogTitle>
          <DialogDescription>
            Upload a CSV with student data. Include 'studentId' to update existing students.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
            <div className="flex justify-end">
              <Button variant="outline" size="sm" onClick={handleDownloadTemplate}>
                <Download className="mr-2 h-4 w-4" />
                Download Template
              </Button>
            </div>
            <div className="grid w-full max-w-sm items-center gap-1.5">
                 <label htmlFor="csv-file" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    CSV File
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md">
                    <div className="space-y-1 text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="flex text-sm text-gray-600 dark:text-gray-400">
                            <label
                                htmlFor="csv-file-input"
                                className="relative cursor-pointer bg-white dark:bg-gray-900 rounded-md font-medium text-primary hover:text-primary/80 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary"
                            >
                                <span>Upload a file</span>
                                <input id="csv-file-input" name="csv-file" type="file" className="sr-only" accept=".csv" onChange={handleFileChange} />
                            </label>
                            <p className="pl-1">or drag and drop</p>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400">CSV up to 10MB</p>
                        {file && <p className="text-sm text-green-600 dark:text-green-400 mt-2">{file.name}</p>}
                    </div>
                </div>
            </div>
          {isLoading && (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}
          {error && (
            <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleImport} disabled={isLoading || !file}>
            {isLoading ? 'Importing...' : 'Import Students'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
