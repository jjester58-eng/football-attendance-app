"use client";

import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { Student } from '@/types';
import { useToast } from '@/hooks/use-toast';

interface EditStudentDialogProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  student: Student;
  onSave: (student: Student) => void;
}

export default function EditStudentDialog({
  isOpen,
  setIsOpen,
  student,
  onSave,
}: EditStudentDialogProps) {
  const [editableStudent, setEditableStudent] = useState<Student>(student);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      setEditableStudent(JSON.parse(JSON.stringify(student)));
    }
  }, [isOpen, student]);

  const handleChange = (field: keyof Omit<Student, 'id'>, value: string) => {
    setEditableStudent(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveChanges = () => {
    if (!editableStudent.name.trim()) {
      toast({
        variant: 'destructive',
        title: 'Invalid Input',
        description: 'Student name cannot be empty.',
      });
      return;
    }
    onSave(editableStudent);
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Edit Student Information</DialogTitle>
          <DialogDescription>
            Update the student's details below. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Name
            </Label>
            <Input
              id="name"
              value={editableStudent.name}
              onChange={e => handleChange('name', e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="parentEmail" className="text-right">
              Parent Email
            </Label>
            <Input
              id="parentEmail"
              value={editableStudent.parentEmail || ''}
              onChange={e => handleChange('parentEmail', e.target.value)}
              className="col-span-3"
              placeholder="Optional"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="group" className="text-right">
              Group
            </Label>
            <Input
              id="group"
              value={editableStudent.group || ''}
              onChange={e => handleChange('group', e.target.value)}
              className="col-span-3"
              placeholder="e.g., Group A, Blue Team"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSaveChanges}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
