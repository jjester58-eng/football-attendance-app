"use client";

import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { suggestCorrections, type SuggestCorrectionsOutput } from '@/ai/flows/suggest-corrections';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface SuggestCorrectionsDialogProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  attendanceRecordsString: string;
  onApplySuggestions: (suggestions: string) => void;
}

export default function SuggestCorrectionsDialog({
  isOpen,
  setIsOpen,
  attendanceRecordsString,
  onApplySuggestions,
}: SuggestCorrectionsDialogProps) {
  const [policies, setPolicies] = useState(
    'Students marked absent for 3 consecutive days without notification should be flagged. Late arrivals over 15 minutes are marked as absent.'
  );
  const [result, setResult] = useState<SuggestCorrectionsOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleSuggest = async () => {
    setIsLoading(true);
    setError(null);
    setResult(null);
    try {
      const response = await suggestCorrections({
        attendanceRecords: attendanceRecordsString,
        attendancePolicies: policies,
      });
      setResult(response);
    } catch (e) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(errorMessage);
      toast({
        variant: 'destructive',
        title: 'Error Generating Suggestions',
        description: errorMessage,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = () => {
    if (result) {
      onApplySuggestions(result.suggestedCorrections);
      setIsOpen(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>AI-Powered Attendance Suggestions</DialogTitle>
          <DialogDescription>
            Let AI analyze attendance records against policies to find inconsistencies and suggest corrections.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="policies">Attendance Policies</Label>
            <Textarea
              id="policies"
              value={policies}
              onChange={(e) => setPolicies(e.target.value)}
              placeholder="Enter your attendance policies here..."
              className="min-h-[100px]"
            />
          </div>
          {isLoading && (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}
          {error && (
            <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {result && (
            <div className="space-y-4">
              <Alert>
                <AlertTitle>Suggested Corrections</AlertTitle>
                <AlertDescription className="whitespace-pre-wrap font-mono text-sm p-2 bg-muted rounded-md mt-2">
                  {result.suggestedCorrections || 'No corrections suggested.'}
                </AlertDescription>
              </Alert>
               <Alert>
                <AlertTitle>Reasoning</AlertTitle>
                <AlertDescription className="whitespace-pre-wrap p-2 bg-muted rounded-md mt-2">
                  {result.reasoning}
                </AlertDescription>
              </Alert>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          {result ? (
            <Button onClick={handleApply}>Apply Suggestions</Button>
          ) : (
            <Button onClick={handleSuggest} disabled={isLoading}>
              {isLoading ? 'Analyzing...' : 'Generate Suggestions'}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
