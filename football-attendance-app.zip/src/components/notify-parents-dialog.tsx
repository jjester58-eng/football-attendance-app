"use client";

import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2, User, Mail, Clock } from 'lucide-react';
import type { Student } from '@/types';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface NotifyParentsDialogProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  absentStudents: Student[];
}

const defaultMessage = `Dear Parent/Guardian,

This is to inform you that your child, {{studentName}}, was marked absent from {{className}} today, {{date}}.

Please contact us if you have any questions.

Sincerely,
The School`;

export default function NotifyParentsDialog({
  isOpen,
  setIsOpen,
  absentStudents,
}: NotifyParentsDialogProps) {
  const [message, setMessage] = useState(defaultMessage);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSend = () => {
    setIsLoading(true);

    const now = new Date();
    const scheduleTime = new Date();
    scheduleTime.setHours(16, 0, 0, 0); // Set to 4:00:00 PM today

    const delayInMs = Math.max(0, scheduleTime.getTime() - now.getTime());

    toast({
        title: 'Notifications Scheduled',
        description: `Notifications for ${absentStudents.length} absent student(s) will be sent at 4:00 PM today.`
    });

    setTimeout(() => {
      absentStudents.forEach((student) => {
        // In a real app, this would trigger an email API.
        // We simulate it with a toast.
        console.log(`Simulating email to ${student.parentEmail} for ${student.name}`);
      });
      
      setIsLoading(false);
      
      // Check if the dialog is still open before showing the final toast
      if(isOpen) {
        setIsOpen(false);
        toast({
          title: 'Notifications Sent',
          description: `Simulated sending notifications to parents of ${absentStudents.length} absent student(s).`,
        });
      }

    }, delayInMs);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
        if(!isLoading) setIsOpen(open);
    }}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Schedule Parent Notifications</DialogTitle>
          <DialogDescription>
            Confirm the message for absent students. Notifications are sent automatically at 4:00 PM each day.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
          <Alert>
             <User className="h-4 w-4"/>
            <AlertTitle>Recipients ({absentStudents.length})</AlertTitle>
            <AlertDescription>
                Notifications will be scheduled for the following students:
                 <ul className="mt-2 list-disc list-inside text-xs">
                    {absentStudents.map(s => <li key={s.id}>{s.name} ({s.parentEmail})</li>)}
                 </ul>
            </AlertDescription>
          </Alert>
          <div className="grid gap-2">
            <Label htmlFor="message">Custom Message</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Enter your notification message here..."
              className="min-h-[150px]"
            />
            <p className="text-xs text-muted-foreground">
                You can use placeholders like {"{{studentName}}"}, {"{{className}}"}, and {"{{date}}"}.
            </p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)} disabled={isLoading}>
            Cancel
          </Button>
          <Button onClick={handleSend} disabled={isLoading}>
            {isLoading ? (
                <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Scheduling...
                </>
            ) : (
                <>
                    <Clock className="mr-2 h-4 w-4"/>
                    Schedule Notifications
                </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
