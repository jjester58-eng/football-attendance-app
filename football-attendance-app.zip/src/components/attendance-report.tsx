"use client"

import React, { useMemo } from 'react';
import type { AttendanceRecord, Student, Class, AttendanceStatus } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Bar, BarChart, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { subDays, format, eachDayOfInterval } from 'date-fns';

interface AttendanceReportProps {
    attendanceRecords: AttendanceRecord[];
    students: Student[];
    classes: Class[];
    selectedClassId: string;
}

const statusColors: Record<AttendanceStatus, string> = {
    present: 'hsl(var(--chart-1))',
    absent: 'hsl(var(--chart-2))',
    late: 'hsl(var(--chart-3))',
    excused: 'hsl(var(--chart-4))',
    injured: 'hsl(var(--chart-5))',
};

export default function AttendanceReport({ attendanceRecords, students, classes, selectedClassId }: AttendanceReportProps) {
    
    const selectedClass = useMemo(() => classes.find(c => c.id === selectedClassId), [classes, selectedClassId]);

    const classStudents = useMemo(() => {
        if (!selectedClass) return [];
        return students.filter(s => selectedClass.studentIds.includes(s.id));
    }, [students, selectedClass]);
    
    const chartData = useMemo(() => {
        if (!selectedClass) return [];
        const last7Days = eachDayOfInterval({ start: subDays(new Date(), 6), end: new Date() });
        return last7Days.map(date => {
            const dateStr = format(date, 'yyyy-MM-dd');
            const recordsForDay = attendanceRecords.filter(r => r.classId === selectedClassId && r.date === dateStr);
            return {
                date: format(date, 'MMM d'),
                present: recordsForDay.filter(r => r.status === 'present').length,
                absent: recordsForDay.filter(r => r.status === 'absent').length,
                late: recordsForDay.filter(r => r.status === 'late').length,
                excused: recordsForDay.filter(r => r.status === 'excused').length,
                injured: recordsForDay.filter(r => r.status === 'injured').length,
            };
        });
    }, [attendanceRecords, selectedClassId]);

    const studentSummary = useMemo(() => {
        return classStudents.map(student => {
            const studentRecords = attendanceRecords.filter(r => r.studentId === student.id && r.classId === selectedClassId);
            return {
                id: student.id,
                name: student.name,
                present: studentRecords.filter(r => r.status === 'present').length,
                absent: studentRecords.filter(r => r.status === 'absent').length,
                late: studentRecords.filter(r => r.status === 'late').length,
                excused: studentRecords.filter(r => r.status === 'excused').length,
                injured: studentRecords.filter(r => r.status === 'injured').length,
                total: studentRecords.length,
            };
        });
    }, [attendanceRecords, classStudents, selectedClassId]);

    if (!selectedClass) {
        return <Card><CardContent><p>Please select a class to view reports.</p></CardContent></Card>;
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>Last 7 Days Attendance Trend</CardTitle>
                    <CardDescription>For {selectedClass.name}</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="h-[300px] w-full">
                        <ResponsiveContainer>
                            <BarChart data={chartData}>
                                <XAxis dataKey="date" stroke="hsl(var(--foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                <YAxis stroke="hsl(var(--foreground))" fontSize={12} tickLine={false} axisLine={false} />
                                <Tooltip
                                    contentStyle={{ 
                                        backgroundColor: 'hsl(var(--background))',
                                        borderColor: 'hsl(var(--border))'
                                    }} 
                                />
                                <Bar dataKey="present" stackId="a" fill={statusColors.present} name="Present" />
                                <Bar dataKey="absent" stackId="a" fill={statusColors.absent} name="Absent" />
                                <Bar dataKey="late" stackId="a" fill={statusColors.late} name="Late" />
                                <Bar dataKey="excused" stackId="a" fill={statusColors.excused} name="Excused" />
                                <Bar dataKey="injured" stackId="a" fill={statusColors.injured} name="Injured" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle>Student Attendance Summary</CardTitle>
                    <CardDescription>Overall attendance for each student in {selectedClass.name}</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Student</TableHead>
                                <TableHead className="text-center">Present</TableHead>
                                <TableHead className="text-center">Absent</TableHead>
                                <TableHead className="text-center">Late</TableHead>
                                <TableHead className="text-center">Excused</TableHead>
                                <TableHead className="text-center">Injured</TableHead>
                                <TableHead className="text-center">Attendance %</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {studentSummary.map(summary => (
                                <TableRow key={summary.id}>
                                    <TableCell className="font-medium">{summary.name}</TableCell>
                                    <TableCell className="text-center">{summary.present}</TableCell>
                                    <TableCell className="text-center">{summary.absent}</TableCell>
                                    <TableCell className="text-center">{summary.late}</TableCell>
                                    <TableCell className="text-center">{summary.excused}</TableCell>
                                    <TableCell className="text-center">{summary.injured}</TableCell>
                                    <TableCell className="text-center">
                                        {summary.total > 0 ?
                                            <Badge variant={((summary.present + summary.late + summary.excused) / summary.total) * 100 >= 80 ? 'default' : 'destructive'}>
                                                {(((summary.present + summary.late + summary.excused) / summary.total) * 100).toFixed(0)}%
                                            </Badge>
                                             : 'N/A'
                                        }
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
