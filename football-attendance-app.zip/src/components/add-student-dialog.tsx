"use client";

import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { Student } from '@/types';
import { useToast } from '@/hooks/use-toast';

interface AddStudentDialogProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  onAdd: (student: Omit<Student, 'id'>) => void;
}

const initialState = {
  name: '',
  parentEmail: '',
  group: '',
};

export default function AddStudentDialog({
  isOpen,
  setIsOpen,
  onAdd,
}: AddStudentDialogProps) {
  const [newStudent, setNewStudent] = useState(initialState);
  const { toast } = useToast();

  const handleChange = (field: keyof typeof initialState, value: string) => {
    setNewStudent(prev => ({ ...prev, [field]: value }));
  };

  const handleAddStudent = () => {
    if (!newStudent.name.trim()) {
      toast({
        variant: 'destructive',
        title: 'Invalid Input',
        description: 'Student name cannot be empty.',
      });
      return;
    }
    onAdd(newStudent);
    setIsOpen(false);
    setNewStudent(initialState); // Reset form after adding
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add New Student</DialogTitle>
          <DialogDescription>
            Enter the student's details below. Click add when you're done.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Name
            </Label>
            <Input
              id="name"
              value={newStudent.name}
              onChange={e => handleChange('name', e.target.value)}
              className="col-span-3"
              placeholder="Student's full name"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="parentEmail" className="text-right">
              Parent Email
            </Label>
            <Input
              id="parentEmail"
              value={newStudent.parentEmail || ''}
              onChange={e => handleChange('parentEmail', e.target.value)}
              className="col-span-3"
              placeholder="Optional"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="group" className="text-right">
              Group
            </Label>
            <Input
              id="group"
              value={newStudent.group || ''}
              onChange={e => handleChange('group', e.target.value)}
              className="col-span-3"
              placeholder="e.g., Group A, Blue Team"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleAddStudent}>Add Student</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
